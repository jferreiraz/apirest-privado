<p>Fiscalização
Avenida Tancredo Neves 999 - Ed. Metropolitano Alfa - 6º andar - Salas 601/602 e 401/402 - Bairro
Caminho das Árvores - Salvador-BA - CEP 41820-021
Telefone: (71) 3311-2583 - www.cra-ba.org.br
PROCESSO CRA Nª 00068/2025
FISCALIZADO(A) REIS CONSULTORIA EMPRESARIAL LTDA
A(o) Diretor(a) de Fiscalização e Registro
Adm. Jair Nascimento Santos
Em 26/02/2025, expedimos auto de infração de Nº 00185/2025 autuando o(a) REIS CONSULTORIA
EMPRESARIAL LTDA, por FALTA DE REGISTRO EMPRESARIAL. Até o momento a empresa não
apresentou defesa ou regularizou a situação. Informo que o(a) fiscalizado(a) é inscrito(a) neste Conselho sim( ) ou
não( X ); explora atividades nos campos da Administração sim ( X ) ou não( ); é reincidente sim( ) ou não( X ).
Encaminho este PAF N.º 00068/2025 para conhecimento e sugestões das providências a serem adotadas.
Salvador, data da Assinatura eletrônica
Adm. Alexandre Seabra de Oliveira Batista
Coordenador de Fiscalização - CRA-BA nº 8.331
A(o) Presidente do CRA/BA
Adm. Ramiro Lubian Carbalhal
Encaminho este Processo Administrativo Fiscal nº 00068/2025 para designação do Conselheiro Relator com vistas a
análise deste processo e do Auto de Infração Nº 00185/2025 .
Salvador, data da Assinatura eletrônica
Adm. Jair Nascimento Santos
Diretor(a) do Setor de Fiscalização e Registro – CRA/BA Nº 20.480
Designo para Relator deste processo de fiscalização o Conselheiro Administrador José Ronaldo Viana de Almeida.
Informação 391 (3248943) SEI 476901.001517/2025-79 / pg. 1
Salvador, data da Assinatura eletrônica
Adm. Ramiro Lubian Carbalhal
Presidente – CRA/BA Nº 2.989
Documento assinado eletronicamente por Adm. Alexandre Seabra de Oliveira Batista,
Coordenador(a), em 14/04/2025, às 14:34, conforme horário oficial de Brasília.
Documento assinado eletronicamente por Adm. Jair Nascimento Santos, Diretor(a), em 14/04/2025,
às 16:13, conforme horário oficial de Brasília.
Documento assinado eletronicamente por Adm. Ramiro Lubian Carbalhal, Presidente, em
15/04/2025, às 18:46, conforme horário oficial de Brasília.
A autenticidade deste documento pode ser conferida no site sei.cfa.org.br/conferir, informando o código
verificador 3248943 e o código CRC 9E8C052F.
Referência: Processo nº 476901.001517/2025-79 SEI nº 3248943
Informação 391 (3248943) SEI 476901.001517/2025-79 / pg. 2</p>
